#! /bin/bash
touch /home/test/ppp
echo "hello good morning" > /home/test/ppp
